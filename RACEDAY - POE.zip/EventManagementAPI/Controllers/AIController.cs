using Microsoft.AspNetCore.Mvc;
using EventManagementAPI.Services;
using EventManagementAPI.Data;
using Microsoft.EntityFrameworkCore;
namespace EventManagementAPI.Controllers{
    [ApiController]
    [Route("api/ai")]
    public class AIController : ControllerBase{
        private readonly EventAIService _ai;
        private readonly AppDbContext _ctx;
        public AIController(EventAIService ai, AppDbContext ctx){ _ai=ai; _ctx=ctx; }
        public class AnalyzeReq{ public string Name { get; set; } = ""; public string Description { get; set; } = ""; }
        [HttpPost("analyze")] public ActionResult Analyze(AnalyzeReq req){ if(string.IsNullOrWhiteSpace(req.Name) || string.IsNullOrWhiteSpace(req.Description)) return BadRequest("Name and Description required"); return Ok(_ai.Analyze(req.Name, req.Description)); }
        [HttpGet("recommend/{id}")] public async Task<ActionResult> Recommend(int id){ var ev=await _ctx.Events.FindAsync(id); if(ev==null) return NotFound(); var all=await _ctx.Events.ToListAsync(); return Ok(_ai.RecommendSimilar(ev, all)); }
    }
}
